package com.example.coba;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class minggu3_FrameLayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minggu3_frame_layout);
    }
}