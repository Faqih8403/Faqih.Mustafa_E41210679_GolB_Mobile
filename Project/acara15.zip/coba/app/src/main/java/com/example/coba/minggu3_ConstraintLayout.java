package com.example.coba;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class minggu3_ConstraintLayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minggu3_constraint_layout);
    }
}